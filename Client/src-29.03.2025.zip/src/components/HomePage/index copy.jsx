import NavbarComp from "../NavbarComp";
import { FaLocationDot } from "react-icons/fa6";
import { TbArrowsExchange } from "react-icons/tb";
import { FaSearch } from "react-icons/fa";
import busImage from "../../assets/busImage.jpg";
import Card from "react-bootstrap/Card";
import { useEffect, useMemo, useRef, useState } from "react";
import { RiSecurePaymentLine } from "react-icons/ri";
import { RiRefund2Line } from "react-icons/ri";
import { SlEarphonesAlt } from "react-icons/sl";
import "./index.css";

const servicesData = [
  {
    img: <RiSecurePaymentLine className="fs-3" />,
    heading: "Secure Payment",
    para: "Integrate secure payment gateways for users to pay for their tickets",
  },
  {
    img: <RiRefund2Line />,
    heading: "Refund Policy",
    para: "Offer options for the users to purchase refundable tickets with clear terms",
  },
  {
    img: <SlEarphonesAlt />,
    heading: "24/7 Support",
    para: "Get assistance anytime through chat, email or phone",
  },
];

const routesData = [
  {
    from: "Visakhapatnam",
    to: "Vijayawada",
    duration: "8 Hrs",
    amenities: ["Internet", "Snacks", "TV", "Mobile Charging"],
    price: "Rs. 1000",
  },
  {
    from: "Chennai Central",
    to: "Hyderabad",
    duration: "10 Hrs",
    amenities: ["Internet", "Snacks", "TV", "Mobile Charging"],
    price: "Rs. 1200",
  },
  {
    from: "Mumbai Central",
    to: "Ahmedabad",
    duration: "7 Hrs",
    amenities: ["Internet", "Snacks", "TV", "Mobile Charging"],
    price: "Rs. 1100",
  },
  {
    from: "Bangalore",
    to: "Kolkata",
    duration: "15 Hrs",
    amenities: ["Internet", "Snacks", "TV", "Mobile Charging"],
    price: "Rs. 2200",
  },
  {
    from: "Vishakhapatnam Junction",
    to: "Delhi",
    duration: "20 Hrs",
    amenities: ["Internet", "Snacks", "TV", "Mobile Charging"],
    price: "Rs. 3000",
  },
  {
    from: "Valsad",
    to: "Varanasi",
    duration: "18 Hrs",
    amenities: ["Internet", "Snacks", "TV", "Mobile Charging"],
    price: "Rs. 2500",
  },
];

const HomePage = () => {
  let stationData = [];
  const [sourceInput, alterSourceInput] = useState(stationData[0].name);
  const [showSourceSuggestionBar, alterShowSourceSuggestionBar] =
    useState(false);
  const [isSourceInFocus, setIsSourceInFocus] = useState(false);
  const sourceFieldRef = useRef(null);
  const [showDestSuggestionBar, alterShowDestSuggestionBar] = useState(false);
  const [destInput, alterDestInput] = useState(stationData[1].name);
  const destSuggestions = useMemo(() => {
    return stationData.filter((item) => {
      return (
        item.name.toLowerCase().includes(destInput.toLowerCase()) &&
        item.name.toLowerCase() !== sourceInput.toLowerCase()
      );
    });
  }, [destInput, sourceInput]);
  const [isDestInFocus, setIsDestInFocus] = useState(false);
  const destFieldRef = useRef(null);
  const sourceSuggestions = useMemo(() => {
    return stationData.filter((item) => {
      return (
        item.name.toLowerCase().includes(sourceInput.toLowerCase()) &&
        item.name.toLowerCase() !== destInput.toLowerCase()
      );
    });
  }, [sourceInput, destInput]);

  const dateInput = () => {
    const todayDate = new Date();
    const year = String(todayDate.getFullYear());
    const month = String(todayDate.getMonth() + 1).padStart(2, "0");
    const day = String(todayDate.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };

  const todayDate = dateInput();

  const [dateOfJourney, alterDateOfJourney] = useState(todayDate);

  useEffect(() => {
    if (
      Array.isArray(sourceSuggestions) &&
      sourceSuggestions.length > 0 &&
      isSourceInFocus
    ) {
      alterShowSourceSuggestionBar(true);
    } else {
      alterShowSourceSuggestionBar(false);
    }
  }, [sourceInput, sourceSuggestions, isSourceInFocus]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        sourceFieldRef.current &&
        !sourceFieldRef.current.contains(event.target)
      ) {
        const isInputASelectedOne = !stationData.some(
          (item) => item.name.toLowerCase() === sourceInput.toLowerCase()
        );
        if (isInputASelectedOne) {
          alterSourceInput(stationData[0].name);
        }
        alterShowSourceSuggestionBar(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [sourceInput]);

  const selectSourceSuggestion = (item) => {
    alterSourceInput(item.name);
    alterShowSourceSuggestionBar(false);
  };

  useEffect(() => {
    if (
      Array.isArray(destSuggestions) &&
      destSuggestions.length > 0 &&
      isDestInFocus
    ) {
      alterShowDestSuggestionBar(true);
    } else {
      alterShowDestSuggestionBar(false);
    }
  }, [destInput, destSuggestions, isDestInFocus]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        sourceFieldRef.current &&
        !sourceFieldRef.current.contains(event.target)
      ) {
        const isInputASelectedOne = !stationData.some(
          (item) => item.name.toLowerCase() === sourceInput.toLowerCase()
        );
        if (isInputASelectedOne) {
          alterSourceInput(stationData[0].name);
        }
        alterShowSourceSuggestionBar(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [sourceInput]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        destFieldRef.current &&
        !destFieldRef.current.contains(event.target)
      ) {
        const isInputASelectedOne = !stationData.some(
          (item) => item.name.toLowerCase() === destInput.toLowerCase()
        );
        if (isInputASelectedOne) {
          alterDestInput(stationData[1].name);
        }
        alterShowDestSuggestionBar(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [destInput]);

  const selectDestSuggestion = (item) => {
    alterDestInput(item.name);
    alterShowDestSuggestionBar(false);
  };

  dateInput();

  useEffect(() => {
    const fetchData = async () => {
      // const response = await fetch("/api/details");
      // const jsonResponse = await response.json();
      // console.log(jsonResponse);
      const response = await fetch("/api/stationData");
      const jsonResponse = await response.json();
      stationData = jsonResponse;
    };
    fetchData();
  }, []);

  return (
    <div>
      <NavbarComp />
      <div className="d-flex flex-column align-items-center justify-content-center mt-5">
        <p className="fs-6 fs-sm-5">Get your bus tickets</p>
        <h1 className="fs-5 fs-sm-1">Find Best Bus For You!</h1>
        <div className=" d-flex flex-column flex-lg-column flex-md-row align-items-center justify-content-center">
          <div className="d-flex flex-column flex-lg-row border p-3 rounded shadow-sm mb-3">
            <div
              className="d-flex align-items-center border border-1 position-relative px-2"
              ref={sourceFieldRef}
            >
              <input
                type="text"
                placeholder="From"
                className="border-0 p-1 no-outline"
                list="from-locations"
                value={sourceInput}
                onChange={(e) => alterSourceInput(e.target.value)}
                onFocus={() => setIsSourceInFocus(true)}
                onBlur={() => setIsSourceInFocus(false)}
              />
              <FaLocationDot />
              {showSourceSuggestionBar && (
                <ul className="suggestion-container">
                  {sourceSuggestions.map((item, index) => (
                    <li
                      key={index}
                      className="station-suggestion-item"
                      onMouseDown={() => selectSourceSuggestion(item)}
                    >
                      <p className="m-0">{item.name}</p>
                      <p className="m-0">{item.code}</p>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <div className="align-self-center exchange-div">
              <TbArrowsExchange className="exchange-symbol" />
            </div>
            <div
              className="d-flex align-items-center border border-1 position-relative px-2"
              ref={destFieldRef}
            >
              <input
                type="text"
                placeholder="To"
                className="border-0 p-1 no-outline"
                list="from-locations"
                value={destInput}
                onChange={(e) => alterDestInput(e.target.value)}
                onFocus={() => setIsDestInFocus(true)}
                onBlur={() => setIsDestInFocus(false)}
              />
              <FaLocationDot />
              {showDestSuggestionBar && (
                <ul className="suggestion-container">
                  {destSuggestions.map((item, index) => (
                    <li
                      key={index}
                      className="station-suggestion-item"
                      onMouseDown={() => selectDestSuggestion(item)}
                    >
                      <p className="m-0">{item.name}</p>
                      <p className="m-0">{item.code}</p>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <input
              type="date"
              className="input-date border border-1 mx-0 mx-lg-3 my-4 my-lg-0 px-3 py-1"
              min={todayDate}
              value={dateOfJourney}
              onChange={(e) => alterDateOfJourney(e.target.value)}
            />
            <button className="home-search-btn">
              <FaSearch /> Search
            </button>
          </div>
          <img src={busImage} className="home-bus-img" />
        </div>
      </div>
      <div className="d-flex flex-column align-items-center p-3">
        <h1>
          Our <span className="text-danger">Services</span>
        </h1>
        <ul className="d-flex flex-wrap justify-content-center justify-content-md-evenly p-0">
          {servicesData.map((item, index) => (
            <li
              key={index}
              className="d-flex flex-column align-items-center p-3 mb-2 me-2 service-item"
              style={{ backgroundColor: "#dadada" }}
            >
              <div className="d-flex align-items-center mb-3">
                <div className="bg-secondary p-1 px-2 rounded-2 me-2">
                  {item.img}
                </div>
                <h1 className="m-0 services-heading">{item.heading}</h1>
              </div>
              <p className="m-0 services-para">{item.para}</p>
            </li>
          ))}
        </ul>
        <h1>
          Popular <span className="text-danger">Routes</span>
        </h1>
        <ul className="p-0 d-flex flex-wrap justify-content-between w-100 popular-routes-container">
          {routesData.map((route, index) => (
            <li
              key={index}
              className="list-unstyled border border-1 rounded-4 p-3 mb-3 popular-route-item"
            >
              <div className="d-flex justify-content-between">
                <p className="mb-2 route-heading">From</p>
                <p className="mb-2 route-heading">To</p>
              </div>
              <div className="d-flex align-items-center">
                <h1 className="route-text">{route.from}</h1>
                <div className="d-flex justify-content-center align-items-center flex-grow-1">
                  <hr className="route-hr" />
                  <p className="border-2 border rounded-4 m-0 route-time-para">
                    10 Hr
                  </p>
                  <hr className="route-hr" />
                </div>
                <h1 className="route-text">{route.to}</h1>
              </div>
              <div className="mt-3 d-flex justify-content-center">
                <button className="bg-danger text-white border-0 rounded-2 reserve-seat-btn">
                  Reserve Seat
                </button>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default HomePage;
