const statusCodes = {
  loading: "LOADING",
  error: "ERROR",
  success: "SUCCESS",
  idle: "IDLE",
};

export default statusCodes;
